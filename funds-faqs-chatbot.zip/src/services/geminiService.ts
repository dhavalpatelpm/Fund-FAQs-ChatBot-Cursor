import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const API_KEY = process.env.GEMINI_API_KEY;

export interface ChatMessage {
  role: "user" | "model";
  text: string;
  sources?: { uri: string; title: string }[];
}

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    if (!API_KEY) {
      throw new Error("GEMINI_API_KEY is not defined");
    }
    this.ai = new GoogleGenAI({ apiKey: API_KEY });
  }

  async generateResponse(prompt: string, history: ChatMessage[] = []): Promise<ChatMessage> {
    const model = "gemini-3-flash-preview";
    
    const systemInstruction = `
You are "Funds-FAQs-ChatBot", an enterprise-grade facts-only mutual fund assistant.
Your goal is to answer factual questions about mutual funds using official sources (AMCs, SEBI, AMFI).

STRICT RULES:
1. FACTS ONLY. Do not interpret, recommend, or compare funds.
2. MAXIMUM 3 SENTENCES per answer.
3. ALWAYS include exactly ONE official source link at the end of the answer in the format: "Source: [Title](URL)".
4. DO NOT compute returns or predict performance.
5. If asked for advice (e.g., "Should I invest?"), refuse politely: "I'm a facts-only assistant and cannot provide investment advice. You can review official scheme documents or factsheets here: https://www.amfiindia.com"
6. If personal info (PAN, Aadhaar, etc.) is detected, respond: "For your safety, please do not share personal financial information here."
7. Only use information from trusted domains: amfiindia.com, sebi.gov.in, and official AMC websites (e.g., hdfcfund.com, icicipruamc.com, sbimf.com).

ANSWER FORMAT:
Answer: <clear factual answer>
Source: <official link>
Last updated from official sources.
    `;

    try {
      const response = await this.ai.models.generateContent({
        model,
        contents: [
          ...history.map(m => ({ role: m.role, parts: [{ text: m.text }] })),
          { role: "user", parts: [{ text: prompt }] }
        ],
        config: {
          systemInstruction,
          tools: [{ googleSearch: {} }],
          temperature: 0.1, // Low temperature for factual accuracy
        },
      });

      let text = response.text || "I'm sorry, I couldn't find a factual answer for that.";
      
      // Extract grounding sources
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      const sources = chunks
        ?.filter(c => c.web)
        ?.map(c => ({ uri: c.web!.uri, title: c.web!.title })) || [];

      // If the model didn't include a source in the text but we have one in metadata, append it
      if (!text.includes("Source:") && sources.length > 0) {
        text += `\n\nSource: [${sources[0].title}](${sources[0].uri})`;
      }

      return {
        role: "model",
        text,
        sources: sources.slice(0, 1),
      };
    } catch (error) {
      console.error("Gemini API Error:", error);
      return {
        role: "model",
        text: "I encountered an error while retrieving information. Please try again later.",
      };
    }
  }
}

export const geminiService = new GeminiService();
