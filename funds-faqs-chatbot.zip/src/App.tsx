import React from 'react';
import { Search, Bell, User, Settings, MoreHorizontal, Video, Phone, Send, Paperclip, Image as ImageIcon, Smile, Mic, Camera, Plus, MessageSquare, Users, Globe } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { geminiService } from './services/geminiService';
import { Message, ChatSession, STARTER_PROMPTS, TRUSTED_AMCS } from './types';

export default function App() {
  const [messages, setMessages] = React.useState<Message[]>([
    {
      id: '1',
      role: 'model',
      text: "Hello 👋\nI can answer factual questions about mutual funds using official AMC, SEBI, and AMFI sources.",
      timestamp: new Date(),
    }
  ]);
  const [input, setInput] = React.useState('');
  const [isLoading, setIsLoading] = React.useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = React.useState(false);
  const scrollRef = React.useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  };

  React.useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSend = async (text: string = input) => {
    if (!text.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      text: text.trim(),
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const history = messages.map(m => ({
        role: m.role,
        text: m.text
      }));

      const response = await geminiService.generateResponse(text, history);
      
      const modelMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: response.text,
        timestamp: new Date(),
        sources: response.sources,
      };

      setMessages(prev => [...prev, modelMessage]);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex h-screen bg-[#F0F2F5] overflow-hidden font-sans relative">
      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar - Left */}
      <aside className={`
        fixed inset-y-0 left-0 z-50 w-80 bg-white border-r border-slate-200 flex flex-col 
        transition-transform duration-300 lg:relative lg:translate-x-0
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="p-6 border-b border-slate-100 flex items-center gap-3">
          <div className="w-10 h-10 bg-brand-primary rounded-xl flex items-center justify-center text-white">
            <MessageSquare size={24} />
          </div>
          <div>
            <h1 className="font-bold text-lg text-slate-800 leading-tight">Chat Bot</h1>
            <p className="text-xs text-slate-400 font-medium">Funds-FAQs-ChatBot</p>
          </div>
        </div>

        <div className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Search chats..." 
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-100 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-primary/20 transition-all"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar px-2">
          <div className="flex gap-1 p-2 mb-2">
            <button className="flex-1 py-2 text-xs font-semibold rounded-lg bg-brand-primary text-white shadow-sm">Direct</button>
            <button className="flex-1 py-2 text-xs font-semibold rounded-lg text-slate-500 hover:bg-slate-50">Group</button>
            <button className="flex-1 py-2 text-xs font-semibold rounded-lg text-slate-500 hover:bg-slate-50">Public</button>
          </div>

          <div className="space-y-1">
            <h3 className="px-4 py-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Recent Chats</h3>
            {[
              { name: 'Mical Clark', msg: 'Nullam facilisis velit.', time: '10:00PM', active: true },
              { name: 'Colin Nathan', msg: 'Nullam facilisis velit.', time: '10:00PM' },
              { name: 'Nathan Johen', msg: 'Nullam facilisis velit.', time: '10:00PM' },
              { name: 'Semi Doe', msg: 'Nullam facilisis velit.', time: '10:00PM' },
              { name: 'Mical', msg: 'Nullam facilisis velit.', time: '10:00PM' },
              { name: 'Johen Doe', msg: 'Nullam facilisis velit.', time: '10:00PM' },
            ].map((chat, i) => (
              <div key={i} className={`flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-colors ${chat.active ? 'bg-slate-50' : 'hover:bg-slate-50'}`}>
                <div className="w-10 h-10 rounded-full bg-slate-200 overflow-hidden">
                  <img src={`https://i.pravatar.cc/150?u=${chat.name}`} alt={chat.name} referrerPolicy="no-referrer" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-baseline">
                    <h4 className="text-sm font-semibold text-slate-800 truncate">{chat.name}</h4>
                    <span className="text-[10px] text-slate-400">{chat.time}</span>
                  </div>
                  <p className="text-xs text-slate-500 truncate">{chat.msg}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </aside>

      {/* Main Chat Area */}
      <main className="flex-1 flex flex-col bg-white relative min-w-0">
        {/* Header */}
        <header className="h-20 border-b border-slate-100 flex items-center justify-between px-4 md:px-6 bg-white z-10">
          <div className="flex items-center gap-3 md:gap-4">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="p-2 text-slate-500 hover:bg-slate-50 rounded-lg lg:hidden"
            >
              <MessageSquare size={20} />
            </button>
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-slate-200 overflow-hidden border-2 border-white shadow-sm">
              <img src="https://i.pravatar.cc/150?u=bot" alt="Bot" referrerPolicy="no-referrer" />
            </div>
            <div>
              <h2 className="font-bold text-slate-800 text-sm md:text-base">Funds-FAQs-ChatBot</h2>
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                <span className="text-[10px] md:text-xs text-slate-400 font-medium">Online</span>
              </div>
            </div>
          </div>
          <div className="flex items-center">
            <span className="font-bold text-slate-800 whitespace-nowrap">Dhaval Patel</span>
          </div>
        </header>

        {/* Messages */}
        <div 
          ref={scrollRef}
          className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 custom-scrollbar bg-[#F8FAFC]"
        >
          <div className="max-w-3xl mx-auto space-y-6">
            <AnimatePresence initial={false}>
              {messages.map((msg) => (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  className={`flex w-full ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`flex gap-2 md:gap-3 w-full max-w-[95%] md:max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                    <div className="w-7 h-7 md:w-8 md:h-8 rounded-full bg-slate-200 flex-shrink-0 overflow-hidden mt-1 shadow-sm">
                      <img 
                        src={msg.role === 'user' ? `https://i.pravatar.cc/150?u=user` : `https://i.pravatar.cc/150?u=bot`} 
                        alt={msg.role} 
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className={`flex flex-col min-w-0 ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                      <div className="flex items-center gap-2 px-1 mb-1">
                        <span className="text-[9px] md:text-[10px] font-bold text-slate-400 uppercase tracking-tighter">
                          {msg.role === 'user' ? 'You' : 'Funds Bot'}
                        </span>
                        <span className="text-[9px] md:text-[10px] text-slate-300">
                          {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <div className={`p-3 md:p-4 shadow-sm w-fit max-w-full ${
                        msg.role === 'user' 
                          ? 'bg-brand-primary text-white rounded-2xl rounded-tr-none' 
                          : 'bg-white text-slate-800 border border-slate-100 rounded-2xl rounded-tl-none'
                      }`}>
                        <p className="text-xs md:text-sm leading-relaxed whitespace-pre-wrap break-words overflow-hidden">{msg.text}</p>
                        
                        {msg.sources && msg.sources.length > 0 && (
                          <div className="mt-3 pt-3 border-t border-slate-100">
                            <p className="text-[10px] font-bold text-slate-400 uppercase mb-1">Official Source</p>
                            {msg.sources.map((source, idx) => (
                              <a 
                                key={idx}
                                href={source.uri}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center gap-1.5 text-xs text-brand-primary hover:underline font-medium"
                              >
                                <Globe size={12} />
                                {source.title}
                              </a>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            {isLoading && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex justify-start"
              >
                <div className="flex gap-3">
                  <div className="w-8 h-8 rounded-full bg-slate-200 overflow-hidden mt-1">
                    <img src="https://i.pravatar.cc/150?u=bot" alt="Bot" referrerPolicy="no-referrer" />
                  </div>
                  <div className="bg-white border border-slate-100 rounded-2xl rounded-tl-none p-4 shadow-sm">
                    <div className="flex gap-1">
                      <div className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                      <div className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                      <div className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {messages.length === 1 && !isLoading && (
              <div className="mt-8">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-3 px-1">Suggested Questions</p>
                <div className="flex overflow-x-auto gap-3 pb-4 no-scrollbar -mx-1 px-1 snap-x">
                  {STARTER_PROMPTS.map((prompt, i) => (
                    <button
                      key={i}
                      onClick={() => handleSend(prompt)}
                      className="flex-shrink-0 w-64 p-4 text-left bg-white border border-slate-100 rounded-xl hover:border-brand-primary hover:shadow-md transition-all group snap-start"
                    >
                      <p className="text-xs md:text-sm text-slate-600 group-hover:text-brand-primary transition-colors line-clamp-2">{prompt}</p>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Disclaimer Bar */}
        <div className="px-4 md:px-6 py-2 bg-amber-50 border-y border-amber-100 flex items-center justify-center gap-2">
          <span className="text-[9px] md:text-[10px] font-bold text-amber-700 uppercase tracking-wider shrink-0">Disclaimer:</span>
          <p className="text-[9px] md:text-[10px] text-amber-600 font-medium text-center">
            This chatbot provides factual information from official mutual fund sources only. It does not provide investment advice.
          </p>
        </div>

        {/* Input Area */}
        <footer className="p-4 md:p-6 bg-white border-t border-slate-100">
          <div className="max-w-3xl mx-auto">
            <div className="relative flex items-center gap-1 md:gap-2 bg-slate-50 border border-slate-100 rounded-2xl p-1.5 md:p-2 focus-within:ring-2 focus-within:ring-brand-primary/10 transition-all">
              <button className="p-1.5 md:p-2 text-slate-400 hover:text-brand-primary transition-colors hidden sm:block">
                <Plus size={18} />
              </button>
              <button className="p-1.5 md:p-2 text-slate-400 hover:text-brand-primary transition-colors hidden sm:block">
                <ImageIcon size={18} />
              </button>
              <button className="p-1.5 md:p-2 text-slate-400 hover:text-brand-primary transition-colors">
                <Smile size={18} />
              </button>
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Say something..."
                className="flex-1 bg-transparent border-none focus:ring-0 text-xs md:text-sm py-1.5 md:py-2"
              />
              <button className="p-1.5 md:p-2 text-slate-400 hover:text-brand-primary transition-colors hidden sm:block">
                <Mic size={18} />
              </button>
              <button className="p-1.5 md:p-2 text-slate-400 hover:text-brand-primary transition-colors hidden sm:block">
                <Camera size={18} />
              </button>
              <button 
                onClick={() => handleSend()}
                disabled={!input.trim() || isLoading}
                className={`p-2 md:p-2.5 rounded-xl transition-all ${
                  input.trim() && !isLoading 
                    ? 'bg-brand-primary text-white shadow-lg shadow-brand-primary/20 hover:scale-105 active:scale-95' 
                    : 'bg-slate-200 text-slate-400'
                }`}
              >
                <Send size={16} md:size={18} />
              </button>
            </div>
          </div>
        </footer>
      </main>

      {/* Right Sidebar - Notifications & Suggestions */}
      <aside className="w-80 bg-white border-l border-slate-200 flex flex-col hidden xl:flex">
        <div className="p-6 border-b border-slate-100">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Search size={18} className="text-slate-400" />
              <input type="text" placeholder="Search" className="text-sm focus:outline-none w-32" />
            </div>
            <div className="flex items-center gap-3">
              <Bell size={18} className="text-slate-400" />
              <User size={18} className="text-slate-400" />
              <Settings size={18} className="text-slate-400" />
            </div>
          </div>

          <h3 className="text-sm font-bold text-slate-800 mb-4">Notification</h3>
          <div className="space-y-4">
            {[
              { name: 'Nathan', time: '23 hours ago', msg: 'Nullam facilisis velit eu nulla dictum volutpat.' },
              { name: 'Christian', time: '3 hours ago', msg: 'Proin iaculis eros non odio ornare efficitur.' },
              { name: 'Dylan', time: 'Yesterday', msg: 'Morbi quis ex eu arcu auctor sagittis.' },
            ].map((notif, i) => (
              <div key={i} className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-slate-100 overflow-hidden flex-shrink-0">
                  <img src={`https://i.pravatar.cc/150?u=${notif.name}`} alt={notif.name} referrerPolicy="no-referrer" />
                </div>
                <div>
                  <div className="flex justify-between items-baseline gap-2">
                    <h4 className="text-xs font-bold text-slate-800">{notif.name}</h4>
                    <span className="text-[10px] text-slate-400 whitespace-nowrap">{notif.time}</span>
                  </div>
                  <p className="text-[11px] text-slate-500 leading-tight mt-0.5">{notif.msg}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="p-6 flex-1 overflow-y-auto custom-scrollbar">
          <h3 className="text-sm font-bold text-slate-800 mb-4">Suggestions</h3>
          <div className="space-y-4">
            {TRUSTED_AMCS.slice(0, 5).map((amc, i) => (
              <div key={i} className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-8 h-8 rounded-full bg-brand-primary/10 flex items-center justify-center text-brand-primary flex-shrink-0">
                    <Globe size={14} />
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-slate-800 truncate">{amc.split(' ')[0]}</h4>
                    <p className="text-[10px] text-slate-400">Official AMC</p>
                  </div>
                </div>
                <button className="px-3 py-1 text-[10px] font-bold text-white bg-brand-primary rounded-lg hover:bg-brand-secondary transition-colors">
                  Add
                </button>
              </div>
            ))}
          </div>
        </div>
      </aside>
    </div>
  );
}
