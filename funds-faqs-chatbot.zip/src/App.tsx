import React from 'react';
import { Search, Bell, User, Settings, MoreHorizontal, Video, Phone, Send, Paperclip, Image as ImageIcon, Smile, Mic, Camera, Plus, MessageSquare, Users, Globe, Sun, Moon } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { geminiService } from './services/geminiService';
import { Message, ChatSession, STARTER_PROMPTS, TRUSTED_AMCS } from './types';

export default function App() {
  const [messages, setMessages] = React.useState<Message[]>([
    {
      id: '1',
      role: 'model',
      text: "Hello 👋\nI can answer factual questions about mutual funds using official AMC, SEBI, and AMFI sources.",
      timestamp: new Date(),
    }
  ]);
  const [input, setInput] = React.useState('');
  const [isLoading, setIsLoading] = React.useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = React.useState(false);
  const [theme, setTheme] = React.useState<'light' | 'dark'>('light');
  const scrollRef = React.useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  };

  React.useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSend = async (text: string = input) => {
    if (!text.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      text: text.trim(),
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    const modelMessageId = (Date.now() + 1).toString();
    const modelMessage: Message = {
      id: modelMessageId,
      role: 'model',
      text: '',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, modelMessage]);

    try {
      const history = messages.map(m => ({
        role: m.role,
        text: m.text
      }));

      const stream = geminiService.generateResponseStream(text, history);
      
      for await (const chunk of stream) {
        setMessages(prev => prev.map(m => 
          m.id === modelMessageId 
            ? { ...m, text: chunk.text, sources: chunk.sources } 
            : m
        ));
      }
    } catch (error) {
      console.error(error);
      setMessages(prev => prev.map(m => 
        m.id === modelMessageId 
          ? { ...m, text: "I encountered an error. Please try again." } 
          : m
      ));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className={`flex h-screen overflow-hidden font-sans relative transition-colors duration-300 ${theme === 'dark' ? 'bg-[#0F172A] text-slate-100' : 'bg-[#F0F2F5] text-slate-800'}`}>
      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar - Left */}
      <aside className={`
        fixed inset-y-0 left-0 z-50 w-80 border-r flex flex-col 
        transition-transform duration-300 lg:relative lg:translate-x-0
        ${theme === 'dark' ? 'bg-[#1E293B] border-slate-700' : 'bg-white border-slate-200'}
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className={`p-6 border-b flex items-center gap-3 ${theme === 'dark' ? 'border-slate-700' : 'border-slate-100'}`}>
          <div className="w-10 h-10 bg-brand-primary rounded-xl flex items-center justify-center text-white">
            <MessageSquare size={24} />
          </div>
          <div>
            <h1 className={`font-bold text-lg leading-tight ${theme === 'dark' ? 'text-white' : 'text-slate-800'}`}>Chat Bot</h1>
            <p className="text-xs text-slate-400 font-medium">Funds-FAQs-ChatBot</p>
          </div>
        </div>

        <div className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Search chats..." 
              className={`w-full pl-10 pr-4 py-2 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-primary/20 transition-all ${
                theme === 'dark' ? 'bg-slate-800 border-slate-700 text-white placeholder:text-slate-500' : 'bg-slate-50 border-slate-100 text-slate-800'
              }`}
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar px-2">
          <div className={`flex gap-1 p-2 mb-2 rounded-xl ${theme === 'dark' ? 'bg-slate-800/50' : 'bg-slate-50'}`}>
            <button className="flex-1 py-2 text-xs font-semibold rounded-lg bg-brand-primary text-white shadow-sm">Direct</button>
            <button className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-colors ${theme === 'dark' ? 'text-slate-400 hover:bg-slate-700' : 'text-slate-500 hover:bg-slate-100'}`}>Group</button>
            <button className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-colors ${theme === 'dark' ? 'text-slate-400 hover:bg-slate-700' : 'text-slate-500 hover:bg-slate-100'}`}>Public</button>
          </div>

          <div className="space-y-1">
            <h3 className="px-4 py-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Recent Chats</h3>
            {[
              { name: 'Mical Clark', msg: 'Nullam facilisis velit.', time: '10:00PM', active: true },
              { name: 'Colin Nathan', msg: 'Nullam facilisis velit.', time: '10:00PM' },
              { name: 'Nathan Johen', msg: 'Nullam facilisis velit.', time: '10:00PM' },
              { name: 'Semi Doe', msg: 'Nullam facilisis velit.', time: '10:00PM' },
              { name: 'Mical', msg: 'Nullam facilisis velit.', time: '10:00PM' },
              { name: 'Johen Doe', msg: 'Nullam facilisis velit.', time: '10:00PM' },
            ].map((chat, i) => (
              <div key={i} className={`flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-colors ${
                chat.active 
                  ? (theme === 'dark' ? 'bg-slate-700/50' : 'bg-slate-50') 
                  : (theme === 'dark' ? 'hover:bg-slate-700/30' : 'hover:bg-slate-50')
              }`}>
                <div className="w-10 h-10 rounded-full bg-slate-200 overflow-hidden shrink-0">
                  <img src={`https://i.pravatar.cc/150?u=${chat.name}`} alt={chat.name} referrerPolicy="no-referrer" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-baseline">
                    <h4 className={`text-sm font-semibold truncate ${theme === 'dark' ? 'text-white' : 'text-slate-800'}`}>{chat.name}</h4>
                    <span className="text-[10px] text-slate-400">{chat.time}</span>
                  </div>
                  <p className="text-xs text-slate-500 truncate">{chat.msg}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </aside>

      {/* Main Chat Area */}
      <main className={`flex-1 flex flex-col relative min-w-0 transition-colors duration-300 ${theme === 'dark' ? 'bg-[#0F172A]' : 'bg-white'}`}>
        {/* Header */}
        <header className={`h-20 border-b flex items-center justify-between px-4 md:px-6 z-10 transition-colors duration-300 ${
          theme === 'dark' ? 'bg-[#1E293B] border-slate-700' : 'bg-white border-slate-100'
        }`}>
          <div className="flex items-center gap-3 md:gap-4">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className={`p-2 rounded-lg lg:hidden transition-colors ${theme === 'dark' ? 'text-slate-400 hover:bg-slate-700' : 'text-slate-500 hover:bg-slate-50'}`}
            >
              <MessageSquare size={20} />
            </button>
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-slate-200 overflow-hidden border-2 border-white shadow-sm shrink-0">
              <img src="https://i.pravatar.cc/150?u=bot" alt="Bot" referrerPolicy="no-referrer" />
            </div>
            <div>
              <h2 className={`font-bold text-sm md:text-base ${theme === 'dark' ? 'text-white' : 'text-slate-800'}`}>Funds-FAQs-ChatBot</h2>
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                <span className="text-[10px] md:text-xs text-slate-400 font-medium">Online</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
              className={`p-2 rounded-xl transition-all ${
                theme === 'dark' 
                  ? 'bg-slate-700 text-amber-400 hover:bg-slate-600' 
                  : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
              }`}
              title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            >
              {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            <div className="flex items-center">
              <span className={`font-bold whitespace-nowrap ${theme === 'dark' ? 'text-white' : 'text-slate-800'}`}>Dhaval Patel</span>
            </div>
          </div>
        </header>

        {/* Messages */}
        <div 
          ref={scrollRef}
          className={`flex-1 overflow-y-auto p-4 md:p-6 space-y-6 custom-scrollbar transition-colors duration-300 ${
            theme === 'dark' ? 'bg-[#0F172A]' : 'bg-[#F8FAFC]'
          }`}
        >
          <div className="max-w-3xl mx-auto space-y-6">
            <AnimatePresence initial={false}>
              {messages.map((msg) => (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  className={`flex w-full ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`flex gap-2 md:gap-3 w-full max-w-[95%] md:max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                    <div className="w-7 h-7 md:w-8 md:h-8 rounded-full bg-slate-200 flex-shrink-0 overflow-hidden mt-1 shadow-sm">
                      <img 
                        src={msg.role === 'user' ? `https://i.pravatar.cc/150?u=user` : `https://i.pravatar.cc/150?u=bot`} 
                        alt={msg.role} 
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className={`flex flex-col min-w-0 ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                      <div className="flex items-center gap-2 px-1 mb-1">
                        <span className="text-[9px] md:text-[10px] font-bold text-slate-400 uppercase tracking-tighter">
                          {msg.role === 'user' ? 'You' : 'Funds Bot'}
                        </span>
                        <span className="text-[9px] md:text-[10px] text-slate-300">
                          {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <div className={`p-3 md:p-4 shadow-sm w-fit max-w-full transition-colors duration-300 ${
                        msg.role === 'user' 
                          ? 'bg-brand-primary text-white rounded-2xl rounded-tr-none' 
                          : (theme === 'dark' ? 'bg-[#1E293B] text-slate-100 border border-slate-700 rounded-2xl rounded-tl-none' : 'bg-white text-slate-800 border border-slate-100 rounded-2xl rounded-tl-none')
                      }`}>
                        <p className="text-xs md:text-sm leading-relaxed whitespace-pre-wrap break-words overflow-hidden">{msg.text}</p>
                        
                        {msg.sources && msg.sources.length > 0 && (
                          <div className={`mt-3 pt-3 border-t ${theme === 'dark' ? 'border-slate-700' : 'border-slate-100'}`}>
                            <p className="text-[10px] font-bold text-slate-400 uppercase mb-1">Official Source</p>
                            {msg.sources.map((source, idx) => (
                              <a 
                                key={idx}
                                href={source.uri}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center gap-1.5 text-xs text-brand-primary hover:underline font-medium"
                              >
                                <Globe size={12} />
                                {source.title}
                              </a>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            {isLoading && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex justify-start"
              >
                <div className="flex gap-3">
                  <div className="w-8 h-8 rounded-full bg-slate-200 overflow-hidden mt-1 shrink-0 shadow-sm">
                    <img src="https://i.pravatar.cc/150?u=bot" alt="Bot" referrerPolicy="no-referrer" />
                  </div>
                  <div className={`border rounded-2xl rounded-tl-none p-4 shadow-sm transition-colors duration-300 ${
                    theme === 'dark' ? 'bg-[#1E293B] border-slate-700' : 'bg-white border-slate-100'
                  }`}>
                    <div className="flex gap-1">
                      <div className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                      <div className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                      <div className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {!isLoading && (
              <div className="mt-8">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-3 px-1">Suggested Questions</p>
                <div className="flex overflow-x-auto gap-3 pb-4 no-scrollbar -mx-1 px-1 snap-x">
                  {STARTER_PROMPTS.map((prompt, i) => (
                    <button
                      key={i}
                      onClick={() => handleSend(prompt)}
                      className={`flex-shrink-0 w-64 p-4 text-left border rounded-xl hover:border-brand-primary hover:shadow-md transition-all group snap-start ${
                        theme === 'dark' ? 'bg-[#1E293B] border-slate-700' : 'bg-white border-slate-100'
                      }`}
                    >
                      <p className={`text-xs md:text-sm group-hover:text-brand-primary transition-colors line-clamp-2 ${
                        theme === 'dark' ? 'text-slate-300' : 'text-slate-600'
                      }`}>{prompt}</p>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Disclaimer Bar */}
        <div className={`px-4 md:px-6 py-2 border-y flex items-center justify-center gap-2 transition-colors duration-300 ${
          theme === 'dark' ? 'bg-slate-900/50 border-slate-800' : 'bg-amber-50 border-amber-100'
        }`}>
          <span className={`text-[9px] md:text-[10px] font-bold uppercase tracking-wider shrink-0 ${
            theme === 'dark' ? 'text-slate-400' : 'text-amber-700'
          }`}>Disclaimer:</span>
          <p className={`text-[9px] md:text-[10px] font-medium text-center ${
            theme === 'dark' ? 'text-slate-500' : 'text-amber-600'
          }`}>
            This chatbot provides factual information from official mutual fund sources only. It does not provide investment advice.
          </p>
        </div>

        {/* Input Area */}
        <footer className={`p-4 md:p-6 border-t transition-colors duration-300 ${
          theme === 'dark' ? 'bg-[#1E293B] border-slate-700' : 'bg-white border-slate-100'
        }`}>
          <div className="max-w-3xl mx-auto">
            <div className={`relative flex items-center gap-1 md:gap-2 border rounded-2xl p-1.5 md:p-2 focus-within:ring-2 focus-within:ring-brand-primary/10 transition-all ${
              theme === 'dark' ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-100'
            }`}>
              <button className="p-1.5 md:p-2 text-slate-400 hover:text-brand-primary transition-colors hidden sm:block">
                <Plus size={18} />
              </button>
              <button className="p-1.5 md:p-2 text-slate-400 hover:text-brand-primary transition-colors hidden sm:block">
                <ImageIcon size={18} />
              </button>
              <button className="p-1.5 md:p-2 text-slate-400 hover:text-brand-primary transition-colors">
                <Smile size={18} />
              </button>
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Say something..."
                className={`flex-1 bg-transparent border-none focus:ring-0 text-xs md:text-sm py-1.5 md:py-2 ${
                  theme === 'dark' ? 'text-white placeholder:text-slate-500' : 'text-slate-800'
                }`}
              />
              <button className="p-1.5 md:p-2 text-slate-400 hover:text-brand-primary transition-colors hidden sm:block">
                <Mic size={18} />
              </button>
              <button className="p-1.5 md:p-2 text-slate-400 hover:text-brand-primary transition-colors hidden sm:block">
                <Camera size={18} />
              </button>
              <button 
                onClick={() => handleSend()}
                disabled={!input.trim() || isLoading}
                className={`p-2 md:p-2.5 rounded-xl transition-all ${
                  input.trim() && !isLoading 
                    ? 'bg-brand-primary text-white shadow-lg shadow-brand-primary/20 hover:scale-105 active:scale-95' 
                    : 'bg-slate-200 text-slate-400'
                }`}
              >
                <Send size={16} md:size={18} />
              </button>
            </div>
          </div>
        </footer>
      </main>

      {/* Right Sidebar - Notifications & Suggestions */}
      <aside className={`w-80 border-l flex flex-col hidden xl:flex transition-colors duration-300 ${
        theme === 'dark' ? 'bg-[#1E293B] border-slate-700' : 'bg-white border-slate-200'
      }`}>
        <div className={`p-6 border-b ${theme === 'dark' ? 'border-slate-700' : 'border-slate-100'}`}>
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Search size={18} className="text-slate-400" />
              <input 
                type="text" 
                placeholder="Search" 
                className={`text-sm focus:outline-none w-32 bg-transparent ${theme === 'dark' ? 'text-white placeholder:text-slate-500' : 'text-slate-800'}`} 
              />
            </div>
            <div className="flex items-center gap-3">
              <Bell size={18} className="text-slate-400" />
              <User size={18} className="text-slate-400" />
              <Settings size={18} className="text-slate-400" />
            </div>
          </div>

          <h3 className={`text-sm font-bold mb-4 ${theme === 'dark' ? 'text-white' : 'text-slate-800'}`}>Notification</h3>
          <div className="space-y-4">
            {[
              { name: 'Nathan', time: '23 hours ago', msg: 'Nullam facilisis velit eu nulla dictum volutpat.' },
              { name: 'Christian', time: '3 hours ago', msg: 'Proin iaculis eros non odio ornare efficitur.' },
              { name: 'Dylan', time: 'Yesterday', msg: 'Morbi quis ex eu arcu auctor sagittis.' },
            ].map((notif, i) => (
              <div key={i} className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-slate-100 overflow-hidden flex-shrink-0 shadow-sm">
                  <img src={`https://i.pravatar.cc/150?u=${notif.name}`} alt={notif.name} referrerPolicy="no-referrer" />
                </div>
                <div>
                  <div className="flex justify-between items-baseline gap-2">
                    <h4 className={`text-xs font-bold ${theme === 'dark' ? 'text-white' : 'text-slate-800'}`}>{notif.name}</h4>
                    <span className="text-[10px] text-slate-400 whitespace-nowrap">{notif.time}</span>
                  </div>
                  <p className="text-[11px] text-slate-500 leading-tight mt-0.5">{notif.msg}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="p-6 flex-1 overflow-y-auto custom-scrollbar">
          <h3 className={`text-sm font-bold mb-4 ${theme === 'dark' ? 'text-white' : 'text-slate-800'}`}>Suggestions</h3>
          <div className="space-y-4">
            {TRUSTED_AMCS.slice(0, 5).map((amc, i) => (
              <div key={i} className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-8 h-8 rounded-full bg-brand-primary/10 flex items-center justify-center text-brand-primary flex-shrink-0">
                    <Globe size={14} />
                  </div>
                  <div className="min-w-0">
                    <h4 className={`text-xs font-bold truncate ${theme === 'dark' ? 'text-white' : 'text-slate-800'}`}>{amc.split(' ')[0]}</h4>
                    <p className="text-[10px] text-slate-400">Official AMC</p>
                  </div>
                </div>
                <button className="px-3 py-1 text-[10px] font-bold text-white bg-brand-primary rounded-lg hover:bg-brand-secondary transition-colors">
                  Add
                </button>
              </div>
            ))}
          </div>
        </div>
      </aside>
    </div>
  );
}
