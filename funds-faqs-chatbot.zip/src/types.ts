export interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
  sources?: { uri: string; title: string }[];
}

export interface ChatSession {
  id: string;
  title: string;
  lastMessage: string;
  timestamp: Date;
}

export const STARTER_PROMPTS = [
  "Expense ratio of SBI Bluechip Fund",
  "Exit load of HDFC Flexicap Fund",
  "Minimum SIP for ICICI Prudential Value Discovery Fund",
  "ELSS lock-in period",
  "How to download capital gains statement"
];

export const TRUSTED_AMCS = [
  "HDFC Asset Management Co Ltd",
  "ICICI Prudential Asset Management Co Ltd",
  "SBI Funds Management Ltd",
  "Nippon Life India Asset Management Ltd",
  "Kotak Mahindra Asset Management Co Ltd",
  "Axis Asset Management Company Limited",
  "Mirae Asset Investment Managers India",
  "Aditya Birla Sun Life AMC Ltd",
  "PPFAS Asset Management Pvt Ltd",
  "UTI Asset Management Co Ltd",
  "Tata Asset Management Pvt Ltd",
  "Edelweiss Asset Management Limited",
  "DSP Asset Managers Private Limited",
  "Motilal Oswal Asset Management Company"
];
