# Funds-FAQs-ChatBot Architecture

This document outlines the technical architecture and design principles of the Funds-FAQs-ChatBot application.

## 1. Overview
The Funds-FAQs-ChatBot is an enterprise-grade AI assistant designed to provide factual information about mutual funds in India. It leverages real-time data grounding via Google Search and strictly adheres to official sources (AMC, SEBI, AMFI).

## 2. Tech Stack
- **Frontend**: React 19, Tailwind CSS, Framer Motion (motion/react), Lucide React.
- **Backend**: Node.js, Express (serving as a proxy and asset server).
- **AI Model**: Google Gemini 3 Flash.
- **Grounding**: Google Search Tool (integrated via Gemini SDK).
- **Build System**: Vite.

## 3. Frontend Architecture
The frontend is built as a Single Page Application (SPA) with a focus on responsiveness and real-time interaction.

- **Component Structure**:
  - `App.tsx`: Main entry point managing chat state, message history, and the primary UI layout.
  - **Sidebars**: Responsive navigation and suggestion panels.
  - **Chat Area**: Message thread with `AnimatePresence` for smooth entry/exit animations.
- **State Management**: React `useState` and `useEffect` hooks manage the chat history, input state, and loading indicators.
- **Styling**: Utility-first CSS using Tailwind CSS with custom theme configurations in `index.css`.

## 4. Backend Architecture
The application uses a hybrid architecture where the Express server handles API requests and serves the Vite-built frontend.

- **Server (`server.ts`)**:
  - Integrates Vite as middleware for development.
  - Provides a foundation for future API expansions (e.g., user authentication, session persistence).
  - Configured to run on port 3000 as per platform requirements.

## 5. AI Integration (Gemini)
The core intelligence resides in `src/services/geminiService.ts`.

- **Model Configuration**:
  - Uses `gemini-3-flash-preview` for low-latency, high-accuracy responses.
  - **System Instructions**: Strictly enforces factual constraints, domain whitelisting, and safety protocols (no investment advice, no PII).
  - **Grounding**: Uses `googleSearch` tool to fetch live data from trusted domains.
  - **Temperature**: Set to `0.1` to minimize hallucinations and ensure factual consistency.

## 6. Data Flow
1. **User Input**: User types a query in the React UI.
2. **Service Call**: `App.tsx` calls `geminiService.generateResponse`.
3. **AI Processing**: Gemini processes the prompt with system instructions and triggers a Google Search if needed.
4. **Grounding**: Search results are filtered based on trusted domains (e.g., `amfiindia.com`).
5. **Response Generation**: Gemini generates a concise response with official source citations.
6. **UI Update**: The React app renders the message and source badge.

## 7. Security & Compliance
- **PII Filtering**: AI-level rejection of personal sensitive data.
- **Domain Whitelisting**: Restricts search grounding to official regulatory and AMC websites.
- **Factual Guardrails**: Hard-coded refusals for subjective investment advice or performance predictions.
- **Disclaimer**: Persistent UI disclaimer regarding the nature of the information provided.

## 8. File Structure
- `/src/App.tsx`: Main UI and Chat Logic.
- `/src/services/geminiService.ts`: AI Integration Layer.
- `/src/types.ts`: Shared TypeScript interfaces and constants.
- `/server.ts`: Express server entry point.
- `/src/index.css`: Global styles and Tailwind configuration.
